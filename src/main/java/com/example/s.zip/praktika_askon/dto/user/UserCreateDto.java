package com.example.praktika_askon.dto.user;

public class UserCreateDto {
}
