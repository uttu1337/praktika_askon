package com.example.praktika_askon.service;

public interface UserService {
}
